#pragma once

#include<iostream>
#include<string>

#include"Equipment.h"
#include"Member.h"
//#include"Menu.h"
