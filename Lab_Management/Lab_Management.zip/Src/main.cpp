#include"../Headers/Lib.h"
#include"../Headers/Menu.h"
int main()
{
	MENU Menu;
	Menu.Main_menu();
	return 0;
}